def joke():
    return "Hello how are you"