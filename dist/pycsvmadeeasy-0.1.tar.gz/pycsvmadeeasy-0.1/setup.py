from setuptools import setup

setup(name='pycsvmadeeasy',
      version='0.1',
      description='The funniest joke in the world',
      url='https://github.com/sajeeshe/python-csv-easy',
      author='Python Circus',
      author_email='sajeeshe@gmail.com',
      license='MIT',
      packages=['pycsvmadeeasy'],
      zip_safe=False)
